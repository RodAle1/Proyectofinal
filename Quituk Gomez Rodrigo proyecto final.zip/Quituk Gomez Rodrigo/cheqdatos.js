const correo= document.getElementById("correo");
const usuario= document.getElementById("usuario");

if ( correo=="(user) in users"  )
{
    
}